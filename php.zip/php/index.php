
<!DOCTYPE HTML>
<html>
<?php include("HEAD.PHP"); ?>
<body>
	<!-- header-section-starts -->
   
     <?php include("top-nav.php"); ?>
		
	<div class="full">
    <div class="col-md-3 top-nav">
			<?php include("left-nav.php"); ?>
		<!--banner-section-->
	<div class="col-md-9 main">
		<?php include("banner.php"); ?>
			<!--//banner-section-->
			 <div class="b-bottom"> 
			      <h5 class="top"><a href="single.php">What turn out consetetur sadipscing elit</a></h5>
			      <p>On Aug 25 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>56 </a><a class="span_link" href="single.php"><span class="glyphicon glyphicon-circle-arrow-right"></span></a></p>
				</div>
			 <!--/top-news-->
			  <div class="top-news">
				<div class="top-inner">
					<div class="col-md-6 top-text">
						 <a href="single.php"><img src="images/pic1.jpg" class="img-responsive" alt=""></a>
						    <h5 class="top"><a href="single.php">Consetetur sadipscing elit</a></h5>
							<p>Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt labore dolore magna aliquyam eratsed diam justo duo dolores rebum.</p>
						    <p>On Jun 25 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>56 </a><a class="span_link" href="single.php"><span class="glyphicon glyphicon-circle-arrow-right"></span></a></p>
					 </div>
					<div class="col-md-6 top-text two">
						 <a href="single.php"><img src="images/pic2.jpg" class="img-responsive" alt=""></a>
						    <h5 class="top"><a href="single.php">Consetetur sadipscing elit</a></h5>
							<p>Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt labore dolore magna aliquyam eratsed diam justo duo dolores rebum.</p>
						    <p>On Jun 27 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>56 </a><a class="span_link" href="single.php"><span class="glyphicon glyphicon-circle-arrow-right"></span></a></p>
					 </div>
					 <div class="clearfix"> </div>
				 </div>
				 <div class="top-inner second">
					<div class="col-md-6 top-text">
						 <a href="single.php"><img src="images/pic3.jpg" class="img-responsive" alt=""></a>
						    <h5 class="top"><a href="single.php">Consetetur sadipscing elit</a></h5>
							<p>Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt labore dolore magna aliquyam eratsed diam justo duo dolores rebum.</p>
						    <p>On Jun 25 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>56 </a><a class="span_link" href="single.php"><span class="glyphicon glyphicon-circle-arrow-right"></span></a></p>
					 </div>
					<div class="col-md-6 top-text two">
						 <a href="single.php"><img src="images/pic4.jpg" class="img-responsive" alt=""></a>
						    <h5 class="top"><a href="single.php">Consetetur sadipscing elit</a></h5>
							<p>Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt labore dolore magna aliquyam eratsed diam justo duo dolores rebum.</p>
						    <p>On Jun 27 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>56 </a><a class="span_link" href="single.php"><span class="glyphicon glyphicon-circle-arrow-right"></span></a></p>
					 </div>
					 <div class="clearfix"> </div>
				 </div>
	            </div>
					<!--//top-news-->
		     
			<?php include("news.php"); ?>
			<div class="clearfix"> </div>
	<!--/footer-->
	<?php include("footer.php"); ?>
	
	     