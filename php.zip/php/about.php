<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<?php include("HEAD.PHP"); ?>
<body>
	<!-- header-section-starts -->
   
     <?php include("top-nav.php"); ?>
		
	<div class="full">
    <div class="col-md-3 top-nav">
			<?php include("left-nav.php"); ?>
		<!--banner-section-->
	<div class="col-md-9 main">
		<?php include("banner.php"); ?>
			<!--//banner-section-->
			 <div class="b-bottom"> 
			      <h5 class="top"><a href="single.php">What turn out consetetur sadipscing elit</a></h5>
			      <p>On Aug 25 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>56 </a><a class="span_link" href="single.php"><span class="glyphicon glyphicon-circle-arrow-right"></span></a></p>
				</div>
			<!--/top-news-->
			  <div class="top-news">
				<div class="about-content">
				<!-- about -->
					   <h3 class="tittle">About <i class="glyphicon glyphicon-user"></i></h3>
							<img src="images/ab.jpg" alt=" " />
							<p>Having hands on experience in creating innovative designs, I do offer design 
								solutions which harness the new possibilities of web based communication. 
								<label>I do specialize in all aspects of website designing,Nam libero tempore,aspects of website designing cum soluta nobis est eligendi  theme development,  
							possimus omnis dolor repellendus.Nam libero tempore, cum soluta nobis est eligendi  voluptatum...</label></p>
							<div class="clearfix"></div>
						<p class="nam">Nam libero tempore, cum soluta nobis est eligendi 
							optio cumque nihil impedit quo minus id quod maxime placeat facere 
							possimus, omnis voluptas assumenda est, omnis dolor repellendus.
							Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus 
							saepe eveniet ut et voluptates repudiandae sint Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt labore dolore magna  et molestiae non recusandae.</p>
						<div class="more">
							<a href="single.php">Read More</a>
						</div>
				</div>
				 <div class="top-inner second">
					<div class="col-md-6 top-text">
						 <a href="single.php"><img src="images/pic1.jpg" class="img-responsive" alt=""></a>
						    <h5 class="top"><a href="single.php">Consetetur sadipscing elit</a></h5>
							<p>Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt labore dolore magna aliquyam eratsed diam justo duo dolores rebum.</p>
						    <p>On Jun 25 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>56 </a><a class="span_link" href="single.php"><span class="glyphicon glyphicon-circle-arrow-right"></span></a></p>
					 </div>
					<div class="col-md-6 top-text two">
						 <a href="single.php"><img src="images/pic2.jpg" class="img-responsive" alt=""></a>
						    <h5 class="top"><a href="single.php">Consetetur sadipscing elit</a></h5>
							<p>Consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt labore dolore magna aliquyam eratsed diam justo duo dolores rebum.</p>
						    <p>On Jun 27 <a class="span_link" href="#"><span class="glyphicon glyphicon-comment"></span>0 </a><a class="span_link" href="#"><span class="glyphicon glyphicon-eye-open"></span>56 </a><a class="span_link" href="single.php"><span class="glyphicon glyphicon-circle-arrow-right"></span></a></p>
					 </div>
					 <div class="clearfix"> </div>
				 </div>
	            </div>
					<!--//top-news-->
			  
		     
			<?php include("news.php"); ?>
			<div class="clearfix"> </div>
	<!--/footer-->
	<?php include("footer.php"); ?>
	
	     